﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows;

namespace MaxTemp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnAuswerten_Click(object sender, RoutedEventArgs e)
        {
            string filename = "temps.csv";

            if (!File.Exists(filename))
            {
                MessageBox.Show("temps.csv not found in output folder!");
                return;
            }

            var culture = CultureInfo.InvariantCulture;

            // Structure:
            // Date -> (Sensor -> MaxTemp)
            var data = new Dictionary<DateTime, Dictionary<string, double>>();

            try
            {
                foreach (var line in File.ReadLines(filename))
                {
                    if (string.IsNullOrWhiteSpace(line))
                        continue;

                    var parts = line.Split(',');
                    if (parts.Length != 3)
                        continue;

                    string sensor = parts[0].Trim();
                    string timestampText = parts[1].Trim();
                    string tempText = parts[2].Trim();

                    if (!DateTime.TryParseExact(timestampText,
                        "yyyy-MM-dd HH:mm:ss",
                        culture,
                        DateTimeStyles.None,
                        out DateTime timestamp))
                        continue;

                    if (!double.TryParse(tempText,
                        NumberStyles.Float,
                        culture,
                        out double temp))
                        continue;

                    DateTime day = timestamp.Date;

                    if (!data.ContainsKey(day))
                        data[day] = new Dictionary<string, double>();

                    if (!data[day].ContainsKey(sensor) || temp > data[day][sensor])
                        data[day][sensor] = temp;
                }

                if (data.Count == 0)
                {
                    MessageBox.Show("No valid data found.");
                    return;
                }

                // Get all sensors sorted alphabetically
                var allSensors = data
                    .SelectMany(d => d.Value.Keys)
                    .Distinct()
                    .OrderBy(s => s)
                    .ToList();

                // Write pivot-style CSV for gnuplot
                using (StreamWriter writer = new StreamWriter("dailymax.csv"))
                {
                    // Header
                    writer.Write("Date");
                    foreach (var sensor in allSensors)
                        writer.Write("," + sensor);
                    writer.WriteLine();

                    // Sort dates chronologically
                    foreach (var day in data.Keys.OrderBy(d => d))
                    {
                        writer.Write(day.ToString("yyyy-MM-dd"));

                        foreach (var sensor in allSensors)
                        {
                            if (data[day].ContainsKey(sensor))
                                writer.Write("," + data[day][sensor].ToString("0.0", culture));
                            else
                                writer.Write(","); // empty if no value
                        }

                        writer.WriteLine();
                    }
                }

                MessageBox.Show("dailymax.csv successfully created for gnuplot!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}

